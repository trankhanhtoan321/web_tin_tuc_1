<?php include "header.php" ?>
<table style="width:100%">
	<tr>
		<td style="vertical-align:top;width:75%">
			<h1>404 ERROR<br/>
				Có ai ở nhà không!!! <br/>
Ồ Lỗi rồi! Không tìm thấy trang bạn vừa yêu cầu!<br/>
Nguyên nhân có thể do:<br/>
+ Trang này không tồn tại, đã bị xoá.<br/>
+ Trang này đang được bảo trì hoặc nâng cấp.<br/>
+ Do bạn nhập sai địa chỉ của trang. <br/>
+ Địa chỉ của trang web là http://www.laptrinh321.net</h1>
		</td>
<?php include "footer.php" ?>