<meta name="author" content="Trần Khánh Toàn">
<link rel="icon" href="/uploads/images/icon.png" type="image/png" sizes="16x16">	
<!--syntax highlighter-->
<link href="js/syntaxhighlighter/styles/shCoreDefault.css" rel="stylesheet" type="text/css"/>
<script language="javascript" src="js/syntaxhighlighter/scripts/shCore.js"></script>
<script language="javascript" src="js/syntaxhighlighter/scripts/shBrushCpp.js"></script>
<script language="javascript" src="js/syntaxhighlighter/scripts/shBrushPhp.js"></script>
<script language="javascript" src="js/syntaxhighlighter/scripts/shBrushXml.js"></script>
<!--<script language="javascript" src="js/syntaxhighlighter/scripts/shBrushCSharp.js"></script>-->
<!--<script language="javascript" src="js/syntaxhighlighter/scripts/shBrushCss.js"></script>-->
<!--<script language="javascript" src="js/syntaxhighlighter/scripts/shBrushJava.js"></script>-->
<!--<script language="javascript" src="js/syntaxhighlighter/scripts/shBrushJScript.js"></script>-->
<!--<script language="javascript" src="js/syntaxhighlighter/scripts/shBrushSql.js"></script>-->
<!--<script language="javascript" src="js/syntaxhighlighter/scripts/shAutoloader.js"></script>-->
<!--<script language="javascript" src="js/syntaxhighlighter/scripts/shBrushAppleScript.js"></script>-->
<!--<script language="javascript" src="js/syntaxhighlighter/scripts/shBrushAS3.js"></script>-->
<!--<script language="javascript" src="js/syntaxhighlighter/scripts/shBrushBash.js"></script>-->
<!--<script language="javascript" src="js/syntaxhighlighter/scripts/shBrushColdFusion.js"></script>-->
<!--<script language="javascript" src="js/syntaxhighlighter/scripts/shBrushDelphi.js"></script>-->
<!--<script language="javascript" src="js/syntaxhighlighter/scripts/shBrushDiff.js"></script>-->
<!--<script language="javascript" src="js/syntaxhighlighter/scripts/shBrushErlang.js"></script>-->
<!--<script language="javascript" src="js/syntaxhighlighter/scripts/shBrushGroovy.js"></script>-->
<!--<script language="javascript" src="js/syntaxhighlighter/scripts/shBrushJavaFX.js"></script>-->
<!--<script language="javascript" src="js/syntaxhighlighter/scripts/shBrushPerl.js"></script>-->
<!--<script language="javascript" src="js/syntaxhighlighter/scripts/shBrushPlain.js"></script>-->
<!--<script language="javascript" src="js/syntaxhighlighter/scripts/shBrushPowerShell.js"></script>-->
<!--<script language="javascript" src="js/syntaxhighlighter/scripts/shBrushPython.js"></script>-->
<!--<script language="javascript" src="js/syntaxhighlighter/scripts/shBrushRuby.js"></script>-->
<!--<script language="javascript" src="js/syntaxhighlighter/scripts/shBrushSass.js"></script>-->
<!--<script language="javascript" src="js/syntaxhighlighter/scripts/shBrushScala.js"></script>-->
<!--<script language="javascript" src="js/syntaxhighlighter/scripts/shBrushVb.js"></script>-->
<!--<script language="javascript" src="js/syntaxhighlighter/scripts/shLegacy.js"></script>-->
<!--end syntax highlighter-->