<?php
if(@fopen("a.txt","r")) echo "ok";
else echo "no";
?>