<html>
	<head>
		<link href="../css/style.css" rel="stylesheet" type="text/css"/>
	</head>
	<body>
		<?php
		if(isset($_POST['submit']))
		{
			$f=fopen("../config.php","w");
			/////////////////////////////////////////
			$f1=fopen("header.txt","r");
			$s=fread($f1,filesize("header.txt"));
			$s.="\n";
			fclose($f1);
			fwrite($f,$s);
			$s=NULL;
			///////////////////////////////////////
			$s="\$servername = \"".$_POST['servername']."\";\n";
			$s.="\$username = \"".$_POST['username']."\";\n";
			$s.="\$password = \"".$_POST['password']."\";\n";
			$s.="\$dbname = \"".$_POST['dbname']."\";\n";
			$s.="\$homeurl = \"".$_POST['homeurl']."\";\n\n";
			fwrite($f,$s);
			$s=NULL;
			///////////////////////////////////////////
			$f1=fopen("config.txt","r");
			$s=fread($f1,filesize("config.txt"));
			$s.="\n";
			fclose($f1);
			fwrite($f,$s);
			$s=NULL;
			///////////////////////////////////////////
			$f1=fopen("function.txt","r");
			if(filesize("function.txt")>0)
				$s=fread($f1,filesize("function.txt"));
			$s.="\n";
			fclose($f1);
			fwrite($f,$s);
			$s=NULL;
			////////////////////////////////////////////
			$f1=fopen("footer.txt","r");
			$s=fread($f1,filesize("footer.txt"));
			$s.="\n";
			fclose($f1);
			fwrite($f,$s);
			$s=NULL;
			/////////////////////////////////////////
			fclose($f);
			unlink("index.php");
			header("location:../index.php");
		}
		?>
		<div class="header"> cài đặt website</div>
		<form action="" method="post">
			servername:<input type="text" name="servername"/><br/>
			username:<input type="text" name="username"/><br/>
			password:<input type="text" name="password"/><br/>
			database name:<input type="text" name="dbname"/><br/>
			homeurl:<input type="text" name="homeurl"/><br/>
			<input type="submit" name="submit" value="INSTALL"/>
		</form>
	</body>
</html>