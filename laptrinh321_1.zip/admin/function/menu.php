<a href="./"><div class="list-menu">home</div></a>
<a href="./?frame=vietbai"><div class="list-menu">viết bài</div></a>
<a href="./?frame=add_chuyenmuc"><div class="list-menu">thêm chuyên mục</div></a>
<a href="./?frame=del_chuyenmuc"><div class="list-menu">xóa chuyên mục</div></a>
<a href="./?frame=del_baiviet"><div class="list-menu">xóa bài viết</div></a>
<a href="./?frame=edit_baiviet"><div class="list-menu">sửa bài viết</div></a>
<a href="./?frame=menu_tren"><div class="list-menu">menu trên</div></a>
<a target="_blank" href="<?php echo $homeurl; ?>/js/ckfinder/ckfinder.html"><div class="list-menu">file browser</div></a>
<a href="./?frame=edit_config"><div class="list-menu">config</div></a>
<a href="./?frame=cmt"><div class="list-menu">comment</div></a>
<a href="./?frame=sidebar"><div class="list-menu">sidebar</div></a>
<a href="./?frame=menu_footer"><div class="list-menu">menu footer</div></a>
<a href="./?frame=homepage"><div class="list-menu">homepage</div></a>
<a href="./?frame=edit_head"><div class="list-menu">meta header</div></a>
<a href="./logout.php"><div class="list-menu">đăng xuất</div></a>