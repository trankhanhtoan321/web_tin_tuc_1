<table style="width:100%">
	<tr>
		<td width="50%"><a href="<?php echo $homeurl; ?>"><img style="max-width:600px" src="/uploads/images/logo.png"/></a></td>
		<td style="width:50%;text-align:center;vertical-align:middle;">
			<a target="_blank" href="<?php echo $facebook; ?>"><img style="width:30px;height:30px" src="/uploads/images/facebook.png"/></a>
			<a target="_blank" href="<?php echo $google; ?>"><img style="width:30px;height:30px" src="/uploads/images/google.png"/></a>
			<a target="_blank" href="<?php echo $youtube; ?>"><img style="width:30px;height:30px" src="/uploads/images/youtube.png"/></a>
			<br/><br/>
			<form action="timkiem.php" method="get">
				<input type="text" value="từ khóa tìm kiếm" onFocus="this.value='';" name="q"/>
				<input type="submit" value="Tìm Kiếm"/>
			</form>
		</td>
	</tr>
</table>