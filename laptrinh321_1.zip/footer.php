<td style="vertical-align:top;width:25%">
	<?php include "function/sidebar.php"; ?>
</td>
</tr>
</table>
<?php include "function/menu_footer.php"; ?>
<div class="footer">
	<?php echo $option_footer;?>
</div>
<script type="text/javascript">SyntaxHighlighter.all();</script>
</body>
</html>
<?php mysqli_close($conn);?>