<?php 
include "function/moi_nhat.php";
include "function/xemnhieu.php"; 
?>